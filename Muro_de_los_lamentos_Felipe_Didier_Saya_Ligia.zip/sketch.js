let fondo, fondoV2, terrorFont;
let layout = "main";
let images = []; // Arreglo para almacenar las imágenes D1 a D12
let datos;       // Datos de los alumnos
let imageWidth = 80, imageHeight = 80;
let padding = 20;

function preload() {
  fondo = loadImage('fondo.png');      // Cargar la imagen de fondo principal
  fondoV2 = loadImage('V3.jpg');       // Cargar la imagen de fondo para el layout V3
  terrorFont = loadFont('terrorFont.ttf'); // Cargar la fuente personalizada
  
  // Cargar las imágenes D1 a D12
  for (let i = 1; i <= 12; i++) {
    images.push(loadImage(`D${i}.png`)); // Usar comillas invertidas para interpolar i
  }
  
  // Cargar los datos de los alumnos desde el archivo JSON
  loadJSON("datos.json", json => {
    datos = json.alumnos; // Asigna los datos directamente
    asignarImagenesAleatorias(); // Asignar imágenes aleatorias después de cargar los datos
  });
}

function setup() {
  createCanvas(1520, 810); // Tamaño del lienzo basado en tu imagen
}

function asignarImagenesAleatorias() {
  // Asignar una imagen aleatoria a cada alumno
  datos.forEach(alumno => {
    alumno.imagen = random(images); // Asignar imagen aleatoria
  });
}

function draw() {
  if (layout === "main") {
    mostrarLayoutPrincipal();
  } else if (layout === "V2") {
    mostrarLayoutV2();
  }
}

function mostrarLayoutPrincipal() {
  image(fondo, 0, 0, width, height); // Mostrar la imagen de fondo principal
  
  // Configurar fuente y estilo para el texto
  textFont(terrorFont);
  textSize(48);
  fill(255, 165, 0);
  textAlign(CENTER, CENTER);
  text('¿PODRÁS SALVAR TU ALMA?', width / 2, 60);
  textSize(48);
  text('DEL MURO DE LOS LAMENTOS', width / 2, 100);

  // Botón "Mira tu alma"
  drawButton(width / 2, 300, 'Mira tu alma');
}

function mostrarLayoutV2() {
  image(fondoV2, 0, 0, width, height); // Mostrar el fondo V2
  
  // Mostrar el mensaje centrado en grande en el layout 2
  textFont(terrorFont);
  textSize(48);
  fill(255, 0, 0); // Color rojo para destacar el texto
  textAlign(CENTER, CENTER);
  text("Este es el muro de los lamentos", width / 2, 50);
  text("¿podrás salvar tu alma?", width / 2, 120);
  
  // Dibujar las imágenes en una cuadrícula
  let x = 100, y = 200;
  let columnas = 6; // Número de columnas (ajusta según lo que necesites)
  
  for (let i = 0; i < datos.length; i++) {
    let alumno = datos[i];
    let img = alumno.imagen;
    
    // Dibujar la imagen del alumno en la cuadrícula
    image(img, x, y, imageWidth, imageHeight);
    
    // Verificar si el cursor está sobre la imagen para mostrar los datos del alumno
    if (mouseX > x && mouseX < x + imageWidth && mouseY > y && mouseY < y + imageHeight) {
      // Fondo detrás del texto para mejorar la visibilidad
      fill(0, 0, 0, 200); // Fondo negro semitransparente
      rect(x - 15, y - 100, imageWidth + 300, 120, 5); // Rectángulo de fondo detrás del texto, tamaño duplicado nuevamente

      // Texto de nombre, matrícula, grupo, código y fecha de registro
      fill(255, 255, 255); // Texto blanco para mejor contraste
      textSize(16);
      textAlign(LEFT, TOP); // Alinear texto a la izquierda y parte superior
      text(`${alumno.nombre}\nMatrícula: ${alumno.matricula}\nGrupo: ${alumno.grupo}\nCódigo: ${alumno.codigo}\nFecha de Registro: ${alumno.fecha_registro}`, x + 10, y - 95); // Usar comillas invertidas
    }
    
    // Actualizar posición para la siguiente imagen en la cuadrícula
    x += imageWidth + padding;
    if ((i + 1) % 11 === 0) { // Saltar a la siguiente fila después de alcanzar el número de columnas
      x = 100; // Reiniciar posición horizontal
      y += imageHeight + padding; // Mover hacia abajo
    }
  }
}

// Función para dibujar el botón
function drawButton(x, y, label) {
  fill(255, 215, 0);
  rect(x - 75, y, 150, 50, 10);
  fill(0);
  textSize(24);
  textAlign(CENTER, CENTER);
  text(label, x, y + 25);
}

// Evento de mouse para cambiar de layout
function mousePressed() {
  // Si estamos en el layout principal y se hace clic en el botón, cambiar al layout "V2"
  if (layout === "main" && mouseX > width / 2 - 75 && mouseX < width / 2 + 75 && mouseY > 300 && mouseY < 350) {
    layout = "V2";
  }
}
